package com.eternalcalendar.block.entity;

import com.eternalcalendar.EternalCalendarMod;
import com.eternalcalendar.block.ModBlocks;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntities {

    public static class_2591<EternalCalendarBlockEntity> ETERNAL_CALENDAR_BLOCK_ENTITY;

    public static void registerBlockEntities() {
        ETERNAL_CALENDAR_BLOCK_ENTITY = class_2378.method_10230(
                class_7923.field_41181,
                class_2960.method_60655(EternalCalendarMod.MOD_ID, "eternal_calendar_block_entity"),
                FabricBlockEntityTypeBuilder.create(EternalCalendarBlockEntity::new,
                        ModBlocks.ETERNAL_CALENDAR_BLOCK).build()
        );
        EternalCalendarMod.LOGGER.info("[EternalCalendar] Registering block entities...");
    }
}
