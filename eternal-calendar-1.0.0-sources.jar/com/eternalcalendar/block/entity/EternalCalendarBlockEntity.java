package com.eternalcalendar.block.entity;

import com.eternalcalendar.block.EternalCalendarBlock;
import com.eternalcalendar.util.CalendarLogic;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public class EternalCalendarBlockEntity extends class_2586 {

    private int selectedYear = 2024;
    private int selectedMonth = 1;   // 1-12
    private int selectedDay = 1;     // 1-31
    private int dayOfWeek = -1;      // -1 = not calculated, 0=Sun..6=Sat
    private boolean calculated = false;

    public EternalCalendarBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.ETERNAL_CALENDAR_BLOCK_ENTITY, pos, state);
    }

    public void calculate(int year, int month, int day) {
        this.selectedYear = year;
        this.selectedMonth = month;
        this.selectedDay = day;
        this.dayOfWeek = CalendarLogic.getDayOfWeek(year, month, day);
        this.calculated = true;

        if (field_11863 != null && !field_11863.field_9236) {
            // Update block state with redstone power level (1-7 for Sun-Sat, 0 = none)
            int power = calculated ? (dayOfWeek + 1) : 0;
            field_11863.method_8501(field_11867,
                    method_11010()
                            .method_11657(EternalCalendarBlock.POWER, power)
                            .method_11657(EternalCalendarBlock.POWERED, calculated));
            method_5431();
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    public void reset() {
        this.calculated = false;
        this.dayOfWeek = -1;
        if (field_11863 != null && !field_11863.field_9236) {
            field_11863.method_8501(field_11867,
                    method_11010()
                            .method_11657(EternalCalendarBlock.POWER, 0)
                            .method_11657(EternalCalendarBlock.POWERED, false));
            method_5431();
        }
    }

    public int getSelectedYear() { return selectedYear; }
    public int getSelectedMonth() { return selectedMonth; }
    public int getSelectedDay() { return selectedDay; }
    public int getDayOfWeek() { return dayOfWeek; }
    public boolean isCalculated() { return calculated; }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11007(nbt, registryLookup);
        nbt.method_10569("SelectedYear", selectedYear);
        nbt.method_10569("SelectedMonth", selectedMonth);
        nbt.method_10569("SelectedDay", selectedDay);
        nbt.method_10569("DayOfWeek", dayOfWeek);
        nbt.method_10556("Calculated", calculated);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11014(nbt, registryLookup);
        selectedYear = nbt.method_10550("SelectedYear");
        selectedMonth = nbt.method_10550("SelectedMonth");
        selectedDay = nbt.method_10550("SelectedDay");
        dayOfWeek = nbt.method_10550("DayOfWeek");
        calculated = nbt.method_10577("Calculated");
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}
