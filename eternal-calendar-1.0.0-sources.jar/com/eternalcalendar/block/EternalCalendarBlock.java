package com.eternalcalendar.block;

import com.eternalcalendar.block.entity.EternalCalendarBlockEntity;
import com.eternalcalendar.block.entity.ModBlockEntities;
import com.eternalcalendar.screen.EternalCalendarScreenHandler;
import com.eternalcalendar.screen.ModScreenHandlers;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_3965;
import net.minecraft.class_747;
import org.jetbrains.annotations.Nullable;

public class EternalCalendarBlock extends class_2237 {

    public static final MapCodec<EternalCalendarBlock> CODEC = method_54094(EternalCalendarBlock::new);

    public static final class_2753 FACING = class_2741.field_12481;
    // Emits redstone power 1-7 representing day of week (0=no day selected, 1=Sun...7=Sat)
    public static final class_2758 POWER = class_2758.method_11867("power", 0, 7);
    public static final class_2746 POWERED = class_2746.method_11825("powered");

    public EternalCalendarBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664()
                .method_11657(FACING, class_2350.field_11043)
                .method_11657(POWER, 0)
                .method_11657(POWERED, false));
    }

    @Override
    public MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, POWER, POWERED);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos,
                              class_1657 player, class_3965 hit) {
        if (!world.field_9236) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof EternalCalendarBlockEntity calBe) {
                player.method_17355(new class_747(
                        (syncId, inv, p) -> new EternalCalendarScreenHandler(syncId, inv, calBe),
                        class_2561.method_43471("gui.eternalcalendar.calendar_title")
                ));
            }
        }
        return class_1269.field_5812;
    }

    // Redstone output: emits power equal to day-of-week value stored in block entity
    @Override
    public boolean method_9506(class_2680 state) {
        return true;
    }

    @Override
    public int method_9524(class_2680 state, class_1922 world, class_2338 pos, class_2350 direction) {
        return state.method_11654(POWER);
    }

    @Override
    public int method_9603(class_2680 state, class_1922 world, class_2338 pos, class_2350 direction) {
        return state.method_11654(POWER);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new EternalCalendarBlockEntity(pos, state);
    }

    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        return super.method_9576(world, pos, state, player);
    }
}
