package com.eternalcalendar.block;

import com.eternalcalendar.EternalCalendarMod;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_7923;

public class ModBlocks {

    public static final class_2248 ETERNAL_CALENDAR_BLOCK = register(
            "eternal_calendar_block",
            new EternalCalendarBlock(FabricBlockSettings.method_9637()
                    .method_31710(class_3620.field_16012)
                    .method_9629(2.5f, 6.0f)
                    .method_9626(class_2498.field_11547)
                    .method_50012(class_3619.field_15972)
                    .method_22488()
            )
    );

    private static class_2248 register(String name, class_2248 block) {
        class_2248 registered = class_2378.method_10230(class_7923.field_41175,
                class_2960.method_60655(EternalCalendarMod.MOD_ID, name), block);
        class_2378.method_10230(class_7923.field_41178,
                class_2960.method_60655(EternalCalendarMod.MOD_ID, name),
                new class_1747(registered, new class_1792.class_1793()));
        return registered;
    }

    public static void registerBlocks() {
        EternalCalendarMod.LOGGER.info("[EternalCalendar] Registering blocks...");
    }
}
