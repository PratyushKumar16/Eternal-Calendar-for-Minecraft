package com.eternalcalendar.util;

/**
 * Core Eternal Calendar logic, faithfully ported from the original
 * "Eternal Calendar" by Arjun Prasad, B.Sc. Ag (A.U.),
 * K.A.D.C. of Agriculture, Allahabad.
 *
 * Supports both Julian calendar (before Oct 15, 1582) and
 * Gregorian calendar (Oct 15, 1582 onward).
 *
 * Redstone output:
 *   1 = Sunday
 *   2 = Monday
 *   3 = Tuesday
 *   4 = Wednesday
 *   5 = Thursday
 *   6 = Friday
 *   7 = Saturday
 */
public class CalendarLogic {

    public static final String[] DAY_NAMES = {
            "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    };

    public static final String[] DAY_NAMES_SHORT = {
            "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
    };

    public static final String[] MONTH_NAMES = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
    };

    /**
     * Returns the day of week (0=Sunday, 1=Monday ... 6=Saturday)
     * using Zeller's congruence adapted for both Julian and Gregorian calendars,
     * consistent with the Eternal Calendar method.
     *
     * @param year  full year (e.g. 1963, 2024)
     * @param month 1=January ... 12=December
     * @param day   1-31
     */
    public static int getDayOfWeek(int year, int month, int day) {
        // In Zeller's algorithm, January and February are treated as months 13 and 14
        // of the previous year
        if (month < 3) {
            month += 12;
            year -= 1;
        }

        int k = year % 100;       // Year within century
        int j = year / 100;       // Century

        int h;
        boolean isGregorian = isGregorianDate(year + (month >= 13 ? 1 : 0),
                month >= 13 ? month - 12 : month, day);

        if (isGregorian) {
            // Zeller's congruence for Gregorian calendar
            h = (day + (13 * (month + 1)) / 5 + k + k / 4 + j / 4 - 2 * j) % 7;
        } else {
            // Zeller's congruence for Julian calendar
            h = (day + (13 * (month + 1)) / 5 + k + k / 4 + 5 - j) % 7;
        }

        // h: 0=Saturday, 1=Sunday, 2=Monday, ..., 6=Friday
        // Convert to 0=Sunday ... 6=Saturday
        int dow = ((h + 6) % 7);
        return dow;
    }

    /**
     * Check whether a given date falls under the Gregorian calendar system.
     * The Gregorian calendar began on October 15, 1582.
     */
    public static boolean isGregorianDate(int year, int month, int day) {
        if (year > 1582) return true;
        if (year < 1582) return false;
        if (month > 10) return true;
        if (month < 10) return false;
        return day >= 15;
    }

    /**
     * Returns true if the given year is a leap year,
     * applying Julian rules before 1582, Gregorian rules from 1582 onward.
     * Century years (1700, 1800, 1900, 2100, 2200...) are NOT leap years in Gregorian,
     * but divisible-by-400 years (1600, 2000, 2400) ARE.
     * This matches Note (A), (B), (C) from the original Eternal Calendar.
     */
    public static boolean isLeapYear(int year) {
        if (year < 1582) {
            // Julian: every 4th year
            return year % 4 == 0;
        } else {
            // Gregorian rules as specified by the original calendar's notes:
            // "The centurial years, not divisible by 400 are ordinary years.
            //  Accordingly, 1700, 1800, 1900, 2100, 2200 etc. are NOT leap years."
            if (year % 400 == 0) return true;
            if (year % 100 == 0) return false;
            return year % 4 == 0;
        }
    }

    /**
     * Returns how many days are in a given month.
     */
    public static int daysInMonth(int year, int month) {
        return switch (month) {
            case 1, 3, 5, 7, 8, 10, 12 -> 31;
            case 4, 6, 9, 11 -> 30;
            case 2 -> isLeapYear(year) ? 29 : 28;
            default -> 30;
        };
    }

    /**
     * Returns redstone power level for a day of week.
     * 0 = no result, 1=Sunday, 2=Monday, ..., 7=Saturday
     */
    public static int dowToRedstonePower(int dow) {
        return dow + 1; // dow 0-6 → power 1-7
    }

    /**
     * Returns day of week from redstone power level.
     * Returns -1 if power is 0 (no result).
     */
    public static int redstonePowerToDow(int power) {
        if (power == 0) return -1;
        return power - 1;
    }

    /**
     * Get a description of what the redstone signal means.
     * Useful for tooltips and in-game books.
     */
    public static String getRedstoneDescription() {
        return "Redstone output: 1=Sunday, 2=Monday, 3=Tuesday, " +
               "4=Wednesday, 5=Thursday, 6=Friday, 7=Saturday";
    }
}
