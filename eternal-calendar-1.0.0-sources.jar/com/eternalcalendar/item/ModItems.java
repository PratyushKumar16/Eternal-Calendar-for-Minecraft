package com.eternalcalendar.item;

import com.eternalcalendar.EternalCalendarMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItems {

    public static final class_1792 CALENDAR_BOOK = register("calendar_book",
            new CalendarBookItem(new class_1792.class_1793().method_7889(1)));

    public static final class_1792 CALENDAR_PAGE = register("calendar_page",
            new class_1792(new class_1792.class_1793().method_7889(64)));

    private static class_1792 register(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(EternalCalendarMod.MOD_ID, name), item);
    }

    public static void registerItems() {
        EternalCalendarMod.LOGGER.info("[EternalCalendar] Registering items...");
    }
}
