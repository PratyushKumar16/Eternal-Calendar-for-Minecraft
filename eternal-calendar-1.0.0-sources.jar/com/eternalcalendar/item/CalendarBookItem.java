package com.eternalcalendar.item;

import com.eternalcalendar.screen.EternalCalendarScreenHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_747;

public class CalendarBookItem extends class_1792 {

    public CalendarBookItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (!world.field_9236) {
            user.method_17355(new class_747(
                    // For item usage there is no block entity, so pass null
                    (syncId, inv, player) -> new EternalCalendarScreenHandler(syncId, inv, player),
                    class_2561.method_43471("gui.eternalcalendar.calendar_title")
            ));
        }
        return class_1271.method_22427(user.method_5998(hand));
    }
}
