package com.eternalcalendar.screen;

import com.eternalcalendar.block.entity.EternalCalendarBlockEntity;
import com.eternalcalendar.util.CalendarLogic;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

public class EternalCalendarScreenHandler extends class_1703 {

    private final @Nullable EternalCalendarBlockEntity blockEntity;

    // Data synced to client
    private int selectedYear = 2024;
    private int selectedMonth = 1;
    private int selectedDay = 1;
    private int dayOfWeek = -1;
    private boolean calculated = false;

    // Default constructor for ScreenHandlerType registry (no block entity)
    public EternalCalendarScreenHandler(int syncId, class_1661 inv) {
        this(syncId, inv, (EternalCalendarBlockEntity) null);
    }

    // For opening from item (no block entity)
    public EternalCalendarScreenHandler(int syncId, class_1661 inv, class_1657 player) {
        this(syncId, inv, (EternalCalendarBlockEntity) null);
    }

    // For opening from block (with block entity)
    public EternalCalendarScreenHandler(int syncId, class_1661 inv,
                                        @Nullable EternalCalendarBlockEntity blockEntity) {
        super(ModScreenHandlers.ETERNAL_CALENDAR_SCREEN_HANDLER, syncId);
        this.blockEntity = blockEntity;

        if (blockEntity != null) {
            this.selectedYear = blockEntity.getSelectedYear();
            this.selectedMonth = blockEntity.getSelectedMonth();
            this.selectedDay = blockEntity.getSelectedDay();
            this.dayOfWeek = blockEntity.getDayOfWeek();
            this.calculated = blockEntity.isCalculated();
        }
    }

    /**
     * Called from server when client sends a calculate request.
     */
    public void serverCalculate(int year, int month, int day) {
        this.selectedYear = year;
        this.selectedMonth = month;
        this.selectedDay = day;
        this.dayOfWeek = CalendarLogic.getDayOfWeek(year, month, day);
        this.calculated = true;

        if (blockEntity != null) {
            blockEntity.calculate(year, month, day);
        }
    }

    public void serverReset() {
        this.calculated = false;
        this.dayOfWeek = -1;
        if (blockEntity != null) blockEntity.reset();
    }

    // Getters for client screen
    public int getSelectedYear() { return selectedYear; }
    public int getSelectedMonth() { return selectedMonth; }
    public int getSelectedDay() { return selectedDay; }
    public int getDayOfWeek() { return dayOfWeek; }
    public boolean isCalculated() { return calculated; }
    public @Nullable EternalCalendarBlockEntity getBlockEntity() { return blockEntity; }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }
}
