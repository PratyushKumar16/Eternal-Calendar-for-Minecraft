package com.eternalcalendar.screen;

import com.eternalcalendar.EternalCalendarMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Client-to-server packet: tell the server to calculate a date.
 */
public record CalendarCalcPayload(int year, int month, int day) implements class_8710 {

    public static final class_9154<CalendarCalcPayload> ID = new class_9154<>(
            class_2960.method_60655(EternalCalendarMod.MOD_ID, "calendar_calc"));

    public static final class_9139<class_2540, CalendarCalcPayload> CODEC =
            class_9139.method_56438(
                    (value, buf) -> {
                        buf.method_53002(value.year());
                        buf.method_53002(value.month());
                        buf.method_53002(value.day());
                    },
                    buf -> new CalendarCalcPayload(buf.readInt(), buf.readInt(), buf.readInt())
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
