package com.eternalcalendar.screen;

import com.eternalcalendar.EternalCalendarMod;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public class ModNetworking {

    public static void registerServerReceivers() {
        // Register C2S payload types on the server side
        PayloadTypeRegistry.playC2S().register(CalendarCalcPayload.ID, CalendarCalcPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(CalendarResetPayload.ID, CalendarResetPayload.CODEC);

        // Handle calculate request from client
        ServerPlayNetworking.registerGlobalReceiver(CalendarCalcPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                if (context.player().field_7512 instanceof EternalCalendarScreenHandler handler) {
                    handler.serverCalculate(payload.year(), payload.month(), payload.day());
                }
            });
        });

        // Handle reset request from client
        ServerPlayNetworking.registerGlobalReceiver(CalendarResetPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                if (context.player().field_7512 instanceof EternalCalendarScreenHandler handler) {
                    handler.serverReset();
                }
            });
        });

        EternalCalendarMod.LOGGER.info("[EternalCalendar] Registered networking receivers.");
    }
}
