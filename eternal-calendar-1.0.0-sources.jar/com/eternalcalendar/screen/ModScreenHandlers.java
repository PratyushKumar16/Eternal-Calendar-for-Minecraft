package com.eternalcalendar.screen;

import com.eternalcalendar.EternalCalendarMod;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7699;
import net.minecraft.class_7923;

public class ModScreenHandlers {

    public static class_3917<EternalCalendarScreenHandler> ETERNAL_CALENDAR_SCREEN_HANDLER;

    public static void register() {
        ETERNAL_CALENDAR_SCREEN_HANDLER = class_2378.method_10230(
                class_7923.field_41187,
                class_2960.method_60655(EternalCalendarMod.MOD_ID, "eternal_calendar"),
                new class_3917<>(EternalCalendarScreenHandler::new, class_7699.method_45397())
        );
        EternalCalendarMod.LOGGER.info("[EternalCalendar] Registering screen handlers...");
    }
}
