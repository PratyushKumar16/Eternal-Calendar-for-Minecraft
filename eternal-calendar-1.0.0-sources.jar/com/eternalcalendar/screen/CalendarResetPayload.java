package com.eternalcalendar.screen;

import com.eternalcalendar.EternalCalendarMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Client-to-server packet: reset the calendar block.
 */
public record CalendarResetPayload() implements class_8710 {

    public static final class_9154<CalendarResetPayload> ID = new class_9154<>(
            class_2960.method_60655(EternalCalendarMod.MOD_ID, "calendar_reset"));

    public static final class_9139<class_2540, CalendarResetPayload> CODEC =
            class_9139.method_56438((value, buf) -> {}, buf -> new CalendarResetPayload());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
