package com.eternalcalendar.screen;

import com.eternalcalendar.EternalCalendarMod;
import com.eternalcalendar.util.CalendarLogic;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_465;

public class CalendarScreen extends class_465<EternalCalendarScreenHandler> {

    // GUI dimensions
    private static final int GUI_WIDTH = 256;
    private static final int GUI_HEIGHT = 220;

    // State
    private int selectedYear;
    private int selectedMonth;
    private int selectedDay;
    private int dayOfWeek;
    private boolean calculated;

    // Widgets
    private class_4185[] monthButtons = new class_4185[12];
    private class_4185[] dayButtons;
    private class_4185 prevYearBtn, nextYearBtn;
    private class_4185 calculateBtn, resetBtn;

    private static final String[] MONTH_SHORT = {
            "Jan","Feb","Mar","Apr","May","Jun",
            "Jul","Aug","Sep","Oct","Nov","Dec"
    };
    private static final String[] DAY_NAMES = {
            "SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"
    };
    private static final int[] DAY_COLORS = {
            0xFFFF5555, // Sunday    - red
            0xFFFFFF55, // Monday    - yellow
            0xFFAAAAAA, // Tuesday   - gray
            0xFF55FFFF, // Wednesday - aqua
            0xFF55FF55, // Thursday  - green
            0xFFFF55FF, // Friday    - light purple
            0xFFFFAA00  // Saturday  - gold
    };

    public CalendarScreen(EternalCalendarScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2792 = GUI_WIDTH;
        this.field_2779 = GUI_HEIGHT;

        this.selectedYear = handler.getSelectedYear();
        this.selectedMonth = handler.getSelectedMonth();
        this.selectedDay = handler.getSelectedDay();
        this.dayOfWeek = handler.getDayOfWeek();
        this.calculated = handler.isCalculated();
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int x = (field_22789 - GUI_WIDTH) / 2;
        int y = (field_22790 - GUI_HEIGHT) / 2;

        // Year navigation
        prevYearBtn = method_37063(class_4185.method_46430(class_2561.method_43470("◀"), btn -> {
            selectedYear = Math.max(1, selectedYear - 1);
            rebuildDayButtons(x, y);
        }).method_46434(x + 14, y + 28, 14, 14).method_46431());

        nextYearBtn = method_37063(class_4185.method_46430(class_2561.method_43470("▶"), btn -> {
            selectedYear = Math.min(9999, selectedYear + 1);
            rebuildDayButtons(x, y);
        }).method_46434(x + 100, y + 28, 14, 14).method_46431());

        // Fast year nav
        method_37063(class_4185.method_46430(class_2561.method_43470("◀◀"), btn -> {
            selectedYear = Math.max(1, selectedYear - 10);
            rebuildDayButtons(x, y);
        }).method_46434(x + 14, y + 44, 20, 12).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("▶▶"), btn -> {
            selectedYear = Math.min(9999, selectedYear + 10);
            rebuildDayButtons(x, y);
        }).method_46434(x + 94, y + 44, 20, 12).method_46431());

        // Month buttons (3 x 4 grid)
        for (int m = 0; m < 12; m++) {
            final int month = m + 1;
            int col = m % 3;
            int row = m / 3;
            int bx = x + 130 + col * 42;
            int by = y + 28 + row * 16;
            monthButtons[m] = method_37063(class_4185.method_46430(
                    class_2561.method_43470(MONTH_SHORT[m]), btn -> {
                        selectedMonth = month;
                        rebuildDayButtons(x, y);
                        updateMonthHighlights();
                    }).method_46434(bx, by, 38, 13).method_46431());
        }

        // Day buttons
        buildDayButtons(x, y);
        updateMonthHighlights();

        // Calculate button
        calculateBtn = method_37063(class_4185.method_46430(
                class_2561.method_43470("▶ CALCULATE DAY"), btn -> doCalculate()
        ).method_46434(x + 14, y + 172, 120, 16).method_46431());

        // Reset button
        resetBtn = method_37063(class_4185.method_46430(
                class_2561.method_43470("RESET"), btn -> doReset()
        ).method_46434(x + 140, y + 172, 50, 16).method_46431());
    }

    private void buildDayButtons(int x, int y) {
        if (dayButtons != null) {
            for (class_4185 b : dayButtons) method_37066(b);
        }
        int maxDay = CalendarLogic.daysInMonth(selectedYear, selectedMonth);
        dayButtons = new class_4185[maxDay];
        for (int d = 0; d < maxDay; d++) {
            final int day = d + 1;
            int col = d % 7;
            int row = d / 7;
            int bx = x + 14 + col * 17;
            int by = y + 110 + row * 15;
            dayButtons[d] = method_37063(class_4185.method_46430(
                    class_2561.method_43470(day < 10 ? "0" + day : String.valueOf(day)),
                    btn -> { selectedDay = day; updateDayHighlights(); }
            ).method_46434(bx, by, 15, 12).method_46431());
        }
        // Clamp selected day to valid range
        if (selectedDay > maxDay) selectedDay = maxDay;
        updateDayHighlights();
    }

    private void rebuildDayButtons(int x, int y) {
        buildDayButtons(x, y);
    }

    private void updateMonthHighlights() {
        for (int m = 0; m < 12; m++) {
            if (monthButtons[m] != null) {
                boolean active = (m + 1 == selectedMonth);
                monthButtons[m].method_25350(active ? 1.0f : 0.55f);
            }
        }
    }

    private void updateDayHighlights() {
        if (dayButtons == null) return;
        for (int d = 0; d < dayButtons.length; d++) {
            if (dayButtons[d] != null) {
                boolean active = (d + 1 == selectedDay);
                dayButtons[d].method_25350(active ? 1.0f : 0.55f);
            }
        }
    }

    private void doCalculate() {
        dayOfWeek = CalendarLogic.getDayOfWeek(selectedYear, selectedMonth, selectedDay);
        calculated = true;
        // Send to server to update block entity & redstone
        ClientPlayNetworking.send(new CalendarCalcPayload(selectedYear, selectedMonth, selectedDay));
    }

    private void doReset() {
        calculated = false;
        dayOfWeek = -1;
        ClientPlayNetworking.send(new CalendarResetPayload());
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int x = (field_22789 - GUI_WIDTH) / 2;
        int y = (field_22790 - GUI_HEIGHT) / 2;

        // Dark background panel
        context.method_25294(x, y, x + GUI_WIDTH, y + GUI_HEIGHT, 0xFF1A1A2A);
        // Outer/inner border
        context.method_49601(x, y, GUI_WIDTH, GUI_HEIGHT, 0xFF8B1A1A);
        context.method_49601(x + 1, y + 1, GUI_WIDTH - 2, GUI_HEIGHT - 2, 0xFFE03030);

        // Title bar
        context.method_25294(x, y, x + GUI_WIDTH, y + 22, 0xFF0E0E1A);
        context.method_25294(x, y + 22, x + GUI_WIDTH, y + 23, 0xFFE03030);

        // Section: Year
        context.method_25294(x + 10, y + 25, x + 120, y + 60, 0xFF0E0E1A);
        context.method_49601(x + 10, y + 25, 110, 35, 0xFF3A3A5A);

        // Section: Month
        context.method_25294(x + 125, y + 25, x + 248, y + 92, 0xFF0E0E1A);
        context.method_49601(x + 125, y + 25, 123, 67, 0xFF3A3A5A);

        // Section: Days
        context.method_25294(x + 10, y + 95, x + 248, y + 168, 0xFF0E0E1A);
        context.method_49601(x + 10, y + 95, 238, 73, 0xFF3A3A5A);

        // Result panel
        context.method_25294(x + 10, y + 192, x + 248, y + 215, 0xFF060612);
        context.method_49601(x + 10, y + 192, 238, 23, 0xFFFFD700);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // renderBackground draws the vanilla darkened world background
        method_25420(context, mouseX, mouseY, delta);
        // super.render calls drawBackground, then drawForeground — do NOT call drawForeground again
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        // NOTE: drawForeground coordinates are relative to the top-left of the GUI panel (x, y already applied)
        int x = (field_22789 - GUI_WIDTH) / 2;
        int y = (field_22790 - GUI_HEIGHT) / 2;

        // Title — centred in the title bar (relative coords for drawCenteredText)
        context.method_27534(field_22793,
                class_2561.method_43470("✦ ETERNAL CALENDAR ✦"),
                GUI_WIDTH / 2, 7, 0xFFE03030);

        // Year section label
        context.method_27535(field_22793, class_2561.method_43470("YEAR"), 14, 17, 0xFF9A9080);

        // Year value (centred in the year box)
        context.method_27534(field_22793,
                class_2561.method_43470(String.valueOf(selectedYear)),
                57, 30, 0xFFFFD700);

        // Leap year indicator
        if (CalendarLogic.isLeapYear(selectedYear)) {
            context.method_27535(field_22793,
                    class_2561.method_43470("LEAP"), 50, 47, 0xFF55FF55);
        }

        // Gregorian/Julian indicator
        boolean greg = CalendarLogic.isGregorianDate(selectedYear, selectedMonth, selectedDay);
        context.method_27535(field_22793,
                class_2561.method_43470(greg ? "GREGORIAN" : "JULIAN"),
                14, 47, greg ? 0xFF55FFFF : 0xFFAAAAAA);

        // Month section label
        context.method_27535(field_22793, class_2561.method_43470("MONTH"), 128, 17, 0xFF9A9080);

        // Days section label
        context.method_27535(field_22793, class_2561.method_43470("DAY"), 14, 97, 0xFF9A9080);

        // Day-of-week column headers (S M T W T F S) above the day grid
        String[] dayLabels = {"S","M","T","W","T","F","S"};
        int[] dowColors = {0xFFFF5555,0xFFFFFF55,0xFFAAAAAA,0xFF55FFFF,0xFF55FF55,0xFFFF55FF,0xFFFFAA00};
        for (int i = 0; i < 7; i++) {
            context.method_27535(field_22793,
                    class_2561.method_43470(dayLabels[i]),
                    17 + i * 17, 100, dowColors[i]);
        }

        // Result row
        if (calculated && dayOfWeek >= 0) {
            String dayName = DAY_NAMES[dayOfWeek];
            int dayColor = DAY_COLORS[dayOfWeek];
            context.method_27534(field_22793,
                    class_2561.method_43470("⚡ " + dayName + " ⚡"),
                    GUI_WIDTH / 2, 199, dayColor);
            // Redstone signal hint
            context.method_27535(field_22793,
                    class_2561.method_43470("RS:" + (dayOfWeek + 1)),
                    225, 199, 0xFFFF4444);
        } else {
            context.method_27534(field_22793,
                    class_2561.method_43470("[ SELECT DATE & CALCULATE ]"),
                    GUI_WIDTH / 2, 199, 0xFF555566);
        }

        // Selected date summary
        String selText = MONTH_SHORT[selectedMonth - 1] + " " + selectedDay + ", " + selectedYear;
        context.method_27534(field_22793,
                class_2561.method_43470(selText), GUI_WIDTH / 2, 176, 0xFFFFD700);
    }
}
