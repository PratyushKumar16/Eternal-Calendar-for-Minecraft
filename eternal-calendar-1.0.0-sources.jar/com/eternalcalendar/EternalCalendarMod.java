package com.eternalcalendar;

import com.eternalcalendar.block.ModBlocks;
import com.eternalcalendar.block.entity.ModBlockEntities;
import com.eternalcalendar.item.ModItems;
import com.eternalcalendar.screen.ModNetworking;
import com.eternalcalendar.screen.ModScreenHandlers;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EternalCalendarMod implements ModInitializer {

    public static final String MOD_ID = "eternalcalendar";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.registerItems();
        ModBlocks.registerBlocks();
        ModBlockEntities.registerBlockEntities();
        ModScreenHandlers.register();
        ModNetworking.registerServerReceivers();

        // Register item group after items/blocks are registered
        class_1761 itemGroup = FabricItemGroup.builder()
                .method_47320(() -> new class_1799(ModItems.CALENDAR_BOOK))
                .method_47321(class_2561.method_43471("itemgroup.eternalcalendar"))
                .method_47317((ctx, entries) -> {
                    entries.method_45421(ModBlocks.ETERNAL_CALENDAR_BLOCK);
                    entries.method_45421(ModItems.CALENDAR_BOOK);
                    entries.method_45421(ModItems.CALENDAR_PAGE);
                })
                .method_47324();

        class_2378.method_10230(class_7923.field_44687,
                class_2960.method_60655(MOD_ID, "eternal_calendar_group"), itemGroup);

        LOGGER.info("[EternalCalendar] Mod initialized — find the day for any date!");
    }
}
