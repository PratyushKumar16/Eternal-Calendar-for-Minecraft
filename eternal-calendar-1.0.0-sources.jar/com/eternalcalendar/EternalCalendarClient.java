package com.eternalcalendar;

import com.eternalcalendar.screen.CalendarScreen;
import com.eternalcalendar.screen.ModScreenHandlers;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_3929;

public class EternalCalendarClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Register the GUI screen for our screen handler
        class_3929.method_17542(ModScreenHandlers.ETERNAL_CALENDAR_SCREEN_HANDLER, CalendarScreen::new);
    }
}
